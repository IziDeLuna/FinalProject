CREATE PROCEDURE `pGetProjectSupervisors`(`pid` INT(11))
  BEGIN
SELECT e.firstname, e.lastname
FROM employee as e, employee_project as pe
WHERE pe.pid = pid AND e.eid = pe.eid AND e.supervisor = 1;
END