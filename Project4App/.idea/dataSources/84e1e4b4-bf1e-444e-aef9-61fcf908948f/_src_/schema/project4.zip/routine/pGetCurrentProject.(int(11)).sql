CREATE PROCEDURE `pGetCurrentProject`(`eid` INT(11))
  BEGIN

SELECT p.pname, p.start_date,p.end_date,p.location 
FROM projects as p,employee_project as pe
WHERE pe.eid = eid AND pe.pid = p.pid
AND start_date <= SYSDATE() AND end_date >= SYSDATE();



END