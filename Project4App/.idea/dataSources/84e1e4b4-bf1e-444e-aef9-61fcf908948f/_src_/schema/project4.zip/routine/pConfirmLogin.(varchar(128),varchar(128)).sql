CREATE PROCEDURE `pConfirmLogin`(`uname` VARCHAR(128), `pwd` VARCHAR(128))
  BEGIN
SELECT e.eid,e.supervisor
FROM employee as e
WHERE e.username = uname AND e.password = pwd ;
END