CREATE PROCEDURE `pTestProcedure`()
  BEGIN

 SELECT 'TestReturn';
 
END